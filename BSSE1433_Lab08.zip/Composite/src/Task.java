public interface Task {
    void search(String keyword);

}
