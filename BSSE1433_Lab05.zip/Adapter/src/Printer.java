interface Printer {
   void printDoc(String fname);
}
