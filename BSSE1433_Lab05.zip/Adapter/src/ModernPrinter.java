public class ModernPrinter {
    public void printNew(String fname) {
        System.out.println(fname + " printed by modern printer");
    }
}
