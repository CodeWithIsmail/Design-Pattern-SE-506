 interface Factory {
    Chair createChair();

    Table createTable();

    Sofa createSofa();

}
