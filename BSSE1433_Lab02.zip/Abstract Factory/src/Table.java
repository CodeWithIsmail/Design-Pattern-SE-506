interface Table {
    void createTable();
}
