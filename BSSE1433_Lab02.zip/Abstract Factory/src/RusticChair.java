public class RusticChair implements  Chair{
    @Override
    public void createChair() {
        System.out.println("Rustic Chair created");

    }
}
