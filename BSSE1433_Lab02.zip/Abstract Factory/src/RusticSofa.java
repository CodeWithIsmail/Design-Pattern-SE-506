public class RusticSofa implements Sofa{
    @Override
    public void createSofa() {
        System.out.println("Rustic Sofa created");

    }
}
