public class VictorianChair implements Chair{
    @Override
    public void createChair() {
        System.out.println("Victorian Chair created");

    }
}
