interface Sofa {
    void createSofa();
}
