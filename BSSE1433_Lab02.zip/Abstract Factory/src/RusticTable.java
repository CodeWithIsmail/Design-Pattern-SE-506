public class RusticTable implements Table{
    @Override
    public void createTable() {
        System.out.println("Rustic Table created");

    }
}
