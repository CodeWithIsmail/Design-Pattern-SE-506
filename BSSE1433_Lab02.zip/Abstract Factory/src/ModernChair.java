public class ModernChair implements Chair{
    @Override
    public void createChair() {
        System.out.println("Modern Chair created");
    }
}
