interface Chair {
    void createChair();
}
