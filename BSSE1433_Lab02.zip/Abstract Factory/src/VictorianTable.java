public class VictorianTable implements Table{
    @Override
    public void createTable() {
        System.out.println("Victorian Table created");

    }
}
