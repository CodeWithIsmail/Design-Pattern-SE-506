public class ModernTable implements Table{
    @Override
    public void createTable() {
        System.out.println("Modern Table created");

    }
}
