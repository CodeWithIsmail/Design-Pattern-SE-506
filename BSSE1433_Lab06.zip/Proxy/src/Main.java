public class Main {
    public static void main(String[] args) {
        ProxyImage image=new ProxyImage("img1");
        image.display();
        image.display();
    }
}