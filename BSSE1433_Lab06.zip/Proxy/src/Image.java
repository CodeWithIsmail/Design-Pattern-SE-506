interface Image {
    void display();
}
