public interface Builder {
    void setType(String typeName);
    void setFilling(String filling);
    void setSpread(String spread);
}
