public interface Creator {
     LibraryItem factoryMethod(String itemId, String title,String author );
}