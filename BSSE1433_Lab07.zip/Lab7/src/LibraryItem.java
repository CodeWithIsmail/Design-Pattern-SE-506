public interface LibraryItem {
    String getDetails();
    boolean borrowItem();
}


