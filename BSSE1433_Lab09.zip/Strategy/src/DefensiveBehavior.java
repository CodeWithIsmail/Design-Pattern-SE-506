public class DefensiveBehavior implements RobotBehavior {
    @Override
    public void execute() {
        System.out.println("Acting defensively");
    }
}