
public class NormalBehavior implements RobotBehavior {
    @Override
    public void execute() {
        System.out.println("Acting normally");
    }
}