public interface RobotBehavior {
    void execute();
}






