public class AggressiveBehavior implements RobotBehavior {
    @Override
    public void execute() {
        System.out.println("Acting aggressively");
    }
}