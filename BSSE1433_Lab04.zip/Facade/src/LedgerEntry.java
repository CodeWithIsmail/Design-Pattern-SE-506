public class LedgerEntry {
    public void entryLedger(String cardNumber,double amount,String operation){
        System.out.println("Ledger entry: "+cardNumber+" card "+operation+" "+amount+" amount");
    }
}
