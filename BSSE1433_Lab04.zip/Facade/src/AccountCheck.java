public class AccountCheck {
    public boolean checkAccount(String cardNumber) {
        System.out.println(cardNumber + " account checked!");
        return true;
    }
}
