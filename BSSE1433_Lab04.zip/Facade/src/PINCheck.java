public class PINCheck {
    public boolean checkPIN(String cardNumber, String pin) {
        System.out.println(cardNumber + " security pin checked");
        return true;
    }
}
