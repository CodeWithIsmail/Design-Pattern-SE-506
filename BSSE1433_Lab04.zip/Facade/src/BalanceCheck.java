public class BalanceCheck {
    public boolean checkBalance(String cardNumber, double amount) {
        System.out.println(cardNumber + " has enough balance");
        return true;
    }
}
