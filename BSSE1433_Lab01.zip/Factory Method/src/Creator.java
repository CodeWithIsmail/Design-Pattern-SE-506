abstract class Creator {
    public abstract Device factoryMethod(String devicename);
}
